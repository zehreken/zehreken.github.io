This is a project for testing performance of **Entitas ECS** within **Unity**.
