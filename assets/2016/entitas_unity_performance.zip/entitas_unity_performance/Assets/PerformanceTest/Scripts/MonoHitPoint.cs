﻿using UnityEngine;

namespace Performance.Entitas
{
	public class MonoHitPoint : MonoBehaviour
	{
		private int _hitPoint;

		void Start()
		{
			_hitPoint = TestConfig.cubeHitPoint;
		}

		public void DecreaseHp()
		{
			_hitPoint--;
			if (_hitPoint <= 0)
			{
				Destroy(GetComponent<MonoMove>());
			}
		}
	}
}
