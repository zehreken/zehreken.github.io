﻿using UnityEngine;
using System.Collections.Generic;
using System.Diagnostics;

namespace Performance.Entitas
{
	public class Main : MonoBehaviour
	{
		private ITest _test;
		private float _deltatime = 0f;
		private List<float> _lastHundredFps = new List<float>();
		private string _fpsText = "";
		private long _initializeTime = 0;
		private Stopwatch _sw = new Stopwatch();

		void Start()
		{
			//Application.targetFrameRate = 300;
		}

		void Update()
		{
			if (_test != null)
			{
				_test.Update();
				_deltatime += (Time.deltaTime - _deltatime) * 0.1f;

				float miliseconds = _deltatime * 1000f;
				float fps = 1f / _deltatime;

				_lastHundredFps.Add(fps);
				if (_lastHundredFps.Count > 500)
					_lastHundredFps.RemoveAt(0);

				float fpsSum = 0f;
				for (int i = 0; i < _lastHundredFps.Count; i++)
				{
					fpsSum += _lastHundredFps[i];
				}
				float averageFps = fpsSum / _lastHundredFps.Count;

				_fpsText = string.Format("{0:0.0} ms ({1:0.} fps) ({2:0.0} average fps)", miliseconds, fps, averageFps);
			}
		}

		void OnGUI()
		{
			GUI.color = Color.black;
			DrawFPSDisplay();
			DrawButtons();
		}

		private void DrawFPSDisplay()
		{
			GUILayout.Label(_fpsText);
		}

		private void DrawButtons()
		{
			if (_test == null)
			{
				if (GUILayout.Button("MonoTest"))
				{
					_sw.Start();
					_test = new MonoTest();
					_test.Initialize();
					_initializeTime = _sw.ElapsedMilliseconds;
					_sw.Reset();
				}
				if (GUILayout.Button("BigMonoTest"))
				{
					_sw.Start();
					_test = new BigMonoTest();
					_test.Initialize();
					_initializeTime = _sw.ElapsedMilliseconds;
					_sw.Reset();
				}
				if (GUILayout.Button("EntitasTest"))
				{
					_sw.Start();
					_test = new EntitasTest();
					_test.Initialize();
					_initializeTime = _sw.ElapsedMilliseconds;
					_sw.Reset();
				}
				if (GUILayout.Button("UpdatePatternTest"))
				{
					_sw.Start();
					_test = new UpdatePatternTest();
					_test.Initialize();
					_initializeTime = _sw.ElapsedMilliseconds;
					_sw.Reset();
				}
			}
			else
			{
				GUILayout.Label(_test.GetName() + " initialized in " + _initializeTime + " ms");
				if (GUILayout.Button("Stop Test"))
				{
					_test.Destroy();
					_test = null;
					_lastHundredFps = new List<float>();
				}
			}
		}
	}
}
