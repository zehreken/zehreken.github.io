﻿using UnityEngine;
using System.Collections;

namespace Performance.Entitas
{
	public class MonoRotate : MonoBehaviour
	{
		private Transform _transform;
		private float _xVel;
		private float _yVel;
		private float _zVel;

		void Start()
		{
			_transform = transform;
			_xVel = TestConfig.GetAxisVelocity();
			_yVel = TestConfig.GetAxisVelocity();
			_zVel = TestConfig.GetAxisVelocity();
		}

		void Update()
		{
			_transform.Rotate(_xVel * Time.deltaTime, _yVel * Time.deltaTime, _zVel * Time.deltaTime);
		}
	}
}
