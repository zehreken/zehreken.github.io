﻿using UnityEngine;
using System.Collections.Generic;
using Entitas;

namespace Performance.Entitas
{
	public class ParentSystem : IReactiveSystem
	{
		public TriggerOnEvent trigger
		{
			get
			{
				return Matcher.Parent.OnEntityAdded();
			}
		}

		public void Execute(List<Entity> entities)
		{
			foreach (var e in entities)
			{
				e.view.obj.transform.SetParent(e.parent.trns);
				e.view.obj.transform.localScale = Vector3.one;
			}
		}
	}
}
