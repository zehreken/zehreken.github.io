﻿using UnityEngine;
using Entitas;
using System;

namespace Performance.Entitas
{
	public class MoveSystem : ISetPool, IExecuteSystem
	{
		private Pool _pool;

		public void SetPool(Pool pool)
		{
			_pool = pool;
		}

		public void Execute()
		{
			var entities = _pool.GetEntities(Matcher.MoveVelocity);
			for (int i = 0; i < entities.Length; i++)
			{
				MoveVelocity v = entities[i].moveVelocity;
				Transform t = entities[i].trnsfrm.obj;
				entities[i].view.obj.transform.Translate(v.xVel * Time.deltaTime, v.yVel * Time.deltaTime, v.zVel * Time.deltaTime, Space.World);
				if (t.position.x < -TestConfig.BORDER || t.position.x > TestConfig.BORDER)
				{
					t.position = new Vector3(TestConfig.BORDER * Mathf.Sign(t.position.x), t.position.y, t.position.z);
					entities[i].ReplaceMoveVelocity(v.xVel * -1f, v.yVel, v.zVel);
					entities[i].ReplaceHitPoint(entities[i].hitPoint.remainingValue - 1);
				}
				if (t.position.y < -TestConfig.BORDER || t.position.y > TestConfig.BORDER)
				{
					t.position = new Vector3(t.position.x, TestConfig.BORDER * Mathf.Sign(t.position.y), t.position.z);
					entities[i].ReplaceMoveVelocity(v.xVel, v.yVel * -1f, v.zVel);
					entities[i].ReplaceHitPoint(entities[i].hitPoint.remainingValue - 1);
				}
				if (t.position.z < -TestConfig.BORDER || t.position.z > TestConfig.BORDER)
				{
					t.position = new Vector3(t.position.x, t.position.y, TestConfig.BORDER * Mathf.Sign(t.position.z));
					entities[i].ReplaceMoveVelocity(v.xVel, v.yVel, v.zVel * -1f);
					entities[i].ReplaceHitPoint(entities[i].hitPoint.remainingValue - 1);
				}
			}
		}
	}
}

