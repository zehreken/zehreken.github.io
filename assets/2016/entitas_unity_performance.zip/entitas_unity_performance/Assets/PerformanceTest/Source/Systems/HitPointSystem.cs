﻿using System;
using System.Collections.Generic;
using Entitas;

namespace Performance.Entitas
{
	public class HitPointSystem : ISetPool, IReactiveSystem
	{
		private Pool _pool;

		public void SetPool(Pool pool)
		{
			_pool = pool;
		}

		public TriggerOnEvent trigger
		{
			get
			{
				return Matcher.HitPoint.OnEntityAdded();
			}
		}

		public void Execute(List<Entity> entities)
		{
			foreach (Entity e in entities)
			{
				if (e.hitPoint.remainingValue <= 0)
				{
					e.RemoveMoveVelocity();
				}
			}
		}
	}
}
