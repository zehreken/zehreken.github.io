﻿using UnityEngine;
using Entitas;

namespace Performance.Entitas
{
	public class RotateSystem : ISetPool, IExecuteSystem
	{
		private Pool _pool;

		public void SetPool(Pool pool)
		{
			_pool = pool;
		}

		public void Execute()
		{
			var entities = _pool.GetEntities(Matcher.RotateVelocity);
			for (int i = 0; i < entities.Length; i++)
			{
				RotateVelocity v = entities[i].rotateVelocity;
				entities[i].view.obj.transform.Rotate(v.xVel * Time.deltaTime, v.yVel * Time.deltaTime, v.zVel * Time.deltaTime);
			}
		}
	}
}

