﻿using UnityEngine;

namespace Performance.Entitas
{
	public class Actor
	{
		private Transform _transform;
		private float _xVel;
		private float _yVel;
		private float _zVel;
		private float _xVelRotate;
		private float _yVelRotate;
		private float _zVelRotate;
		private int _hitPoint;

		public Actor(Transform parent)
		{
			var cubeClone = Object.Instantiate(Resources.Load<GameObject>("Cube"));
			cubeClone.transform.SetParent(parent);
			_transform = cubeClone.transform;
			_xVel = TestConfig.GetAxisVelocity();
			_yVel = TestConfig.GetAxisVelocity();
			_zVel = TestConfig.GetAxisVelocity();

			_xVelRotate = TestConfig.GetAxisVelocity();
			_yVelRotate = TestConfig.GetAxisVelocity();
			_zVelRotate = TestConfig.GetAxisVelocity();

			_hitPoint = TestConfig.cubeHitPoint;
		}

		public void Update()
		{
			// Move logic
			if (_hitPoint > 0)
			{
				_transform.Translate(_xVel * Time.deltaTime, _yVel * Time.deltaTime, _zVel * Time.deltaTime, Space.World);
				if (_transform.position.x < -TestConfig.BORDER || _transform.position.x > TestConfig.BORDER)
				{
					_transform.position = new Vector3(TestConfig.BORDER * Mathf.Sign(_transform.position.x), _transform.position.y, _transform.position.z);
					_xVel *= -1f;
					_hitPoint--;
				}
				if (_transform.position.y < -TestConfig.BORDER || _transform.position.y > TestConfig.BORDER)
				{
					_transform.position = new Vector3(_transform.position.x, TestConfig.BORDER * Mathf.Sign(_transform.position.y), _transform.position.z);
					_yVel *= -1f;
					_hitPoint--;
				}
				if (_transform.position.z < -TestConfig.BORDER || _transform.position.z > TestConfig.BORDER)
				{
					_transform.position = new Vector3(_transform.position.x, _transform.position.y, TestConfig.BORDER * Mathf.Sign(_transform.position.z));
					_zVel *= -1f;
					_hitPoint--;
				}
			}
			// Rotate logic
			_transform.Rotate(_xVelRotate * Time.deltaTime, _yVelRotate * Time.deltaTime, _zVelRotate * Time.deltaTime);
		}
	}
}
