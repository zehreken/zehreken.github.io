﻿namespace Performance.Entitas
{
	public interface ITest
	{
		void Initialize();
		void Update();
		string GetName();
		void Destroy();
	}
}
