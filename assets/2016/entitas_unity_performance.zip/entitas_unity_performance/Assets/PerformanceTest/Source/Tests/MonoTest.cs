﻿using UnityEngine;

namespace Performance.Entitas
{
	public class MonoTest : ITest
	{
		private GameObject _cubeContainer;

		public MonoTest()
		{
			_cubeContainer = new GameObject("MonoTestContainer");
			for (int i = 0; i < TestConfig.CUBE_COUNT; i++)
			{
				var cubeClone = Object.Instantiate(Resources.Load<GameObject>("Cube"));
				cubeClone.transform.SetParent(_cubeContainer.transform);
				cubeClone.AddComponent<MonoMove>();
				cubeClone.AddComponent<MonoRotate>();
				cubeClone.AddComponent<MonoHitPoint>();
			}
		}

		public void Initialize()
		{
			
		}

		public void Update()
		{

		}

		public string GetName()
		{
			return "MonoTest";
		}

		public void Destroy()
		{
			Object.Destroy(_cubeContainer);
		}
	}
}
