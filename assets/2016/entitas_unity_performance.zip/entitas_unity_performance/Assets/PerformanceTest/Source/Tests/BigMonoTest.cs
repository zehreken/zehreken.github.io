﻿using UnityEngine;

namespace Performance.Entitas
{
	public class BigMonoTest : ITest
	{
		private GameObject _cubeContainer;

		public BigMonoTest()
		{
			_cubeContainer = new GameObject("BigMonoTestContainer");
			for (int i = 0; i < TestConfig.CUBE_COUNT; i++)
			{
				var cubeClone = Object.Instantiate(Resources.Load<GameObject>("Cube"));
				cubeClone.transform.SetParent(_cubeContainer.transform);
				cubeClone.AddComponent<BigMono>();
			}
		}

		public void Initialize()
		{

		}

		public void Update()
		{

		}

		public string GetName()
		{
			return "BigMonoTest";
		}

		public void Destroy()
		{
			Object.Destroy(_cubeContainer);
		}
	}
}
