using Entitas;
using UnityEngine;

namespace Performance.Entitas
{
	public class EntitasTest : ITest
	{
		private Systems _systems;
		private GameObject _cubeContainer;
		private Pools _pools;

		public void Initialize()
		{
			Pools.sharedInstance.SetAllPools(); // This creates all pools
			_pools = Pools.sharedInstance;

			_systems = new Systems();
			//_systems = new Feature("Systems");

			_systems.Add(_pools.pool.CreateSystem(new MoveSystem()));
			_systems.Add(_pools.pool.CreateSystem(new RotateSystem()));
			_systems.Add(_pools.pool.CreateSystem(new ParentSystem()));
			_systems.Add(_pools.pool.CreateSystem(new HitPointSystem()));

			_systems.Initialize();

			_cubeContainer = new GameObject("EntitasTestContainer");
			for (int i = 0; i < TestConfig.CUBE_COUNT; i++)
			{
				var entity = _pools.pool.CreateEntity();
				entity.AddView(Object.Instantiate(Resources.Load<GameObject>("Cube")));
				entity.AddTrnsfrm(entity.view.obj.transform);
				entity.AddMoveVelocity(TestConfig.GetAxisVelocity(), TestConfig.GetAxisVelocity(), TestConfig.GetAxisVelocity());
				entity.AddRotateVelocity(TestConfig.GetAxisVelocity(), TestConfig.GetAxisVelocity(), TestConfig.GetAxisVelocity());
				entity.AddParent(_cubeContainer.transform);
				entity.AddHitPoint(TestConfig.cubeHitPoint);
			}
		}

		public void Update()
		{
			_systems.Execute();
		}

		public string GetName()
		{
			return "EntitasTest";
		}

		public void Destroy()
		{
			_systems.DeactivateReactiveSystems();
			Object.Destroy(_cubeContainer);
			_pools.pool.DestroyAllEntities();
			_pools.pool.Reset();
		}
	}
}
