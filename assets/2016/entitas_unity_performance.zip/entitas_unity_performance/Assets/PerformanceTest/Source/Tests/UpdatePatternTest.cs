﻿using UnityEngine;

namespace Performance.Entitas
{
	public class UpdatePatternTest : ITest
	{
		private GameObject _cubeContainer;
		private Actor[] _actors;

		public UpdatePatternTest()
		{
			_cubeContainer = new GameObject("UpdatePatternTestContainer");
			_actors = new Actor[TestConfig.CUBE_COUNT];
			for (int i = 0; i < TestConfig.CUBE_COUNT; i++)
			{
				_actors[i] = new Actor(_cubeContainer.transform);
			}
		}

		public void Initialize()
		{
			
		}

		public void Update()
		{
			for (int i = 0; i < _actors.Length; i++)
			{
				_actors[i].Update();
			}
		}

		public string GetName()
		{
			return "UpdatePatternTest";
		}

		public void Destroy()
		{
			Object.Destroy(_cubeContainer);
			for (int i = 0; i < TestConfig.CUBE_COUNT; i++)
			{
				_actors[i] = null;
			}
		}
	}
}
