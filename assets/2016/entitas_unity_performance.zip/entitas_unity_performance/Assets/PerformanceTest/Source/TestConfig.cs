﻿using UnityEngine;

namespace Performance.Entitas
{
	public static class TestConfig
	{
		public const int CUBE_COUNT = 5000;
		public const float BORDER = 20f;
		public const int cubeHitPoint = 1000;

		public static float GetAxisVelocity()
		{
			return Random.Range(5f, 15f) * (Random.Range(0, 2) == 0 ? -1f : 1f);
		}
	}
}
