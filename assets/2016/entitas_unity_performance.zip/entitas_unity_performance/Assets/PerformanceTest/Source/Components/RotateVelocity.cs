﻿using Entitas;

namespace Performance.Entitas
{
	public class RotateVelocity : IComponent
	{
		public float xVel;
		public float yVel;
		public float zVel;
	}
}
