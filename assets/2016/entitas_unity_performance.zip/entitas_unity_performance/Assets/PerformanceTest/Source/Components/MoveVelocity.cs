﻿using Entitas;

namespace Performance.Entitas
{
	public class MoveVelocity : IComponent
	{
		public float xVel;
		public float yVel;
		public float zVel;
	}
}
