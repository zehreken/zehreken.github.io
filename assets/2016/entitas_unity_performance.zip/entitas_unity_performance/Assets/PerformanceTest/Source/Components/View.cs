﻿using Entitas;
using UnityEngine;

namespace Performance.Entitas
{
	public class View : IComponent
	{
		public GameObject obj;
	}
}
