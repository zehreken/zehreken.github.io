﻿using Entitas;
using UnityEngine;

namespace Performance.Entitas
{
	public class Trnsfrm : IComponent
	{
		public Transform obj;
	}
}
