﻿using Entitas;

namespace Performance.Entitas
{
	public class HitPoint : IComponent
	{
		public int remainingValue;
	}
}
