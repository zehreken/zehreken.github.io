﻿using Entitas;
using UnityEngine;

namespace Performance.Entitas
{
	public class Parent : IComponent
	{
		public Transform trns;
	}
}
