﻿using UnityEngine;
using System;
using System.Collections.Generic;

namespace Performance.Entitas
{
	public static class SimpleBus
	{
		private static Dictionary<GameEvent, List<Action<Dictionary<string, object>>>> gameEvents = new Dictionary<GameEvent, List<Action<Dictionary<string, object>>>>();

		public static void PublishGameEvent(GameEvent e, Dictionary<string, object> data = null)
		{
			if (!gameEvents.ContainsKey(e))
			{
				Debug.Log("<color=red>ERROR: </color>Event " + e + " not found in gameEvents.");
				return;
			}
			foreach (var a in gameEvents[e])
			{
				a(data);
			}
		}

		public static void SubscribeGameEvent(GameEvent e, Action<Dictionary<string, object>> a)
		{
			if (!gameEvents.ContainsKey(e))
			{
				gameEvents.Add(e, new List<Action<Dictionary<string, object>>>());
			}
			gameEvents[e].Add(a);
		}

		public static void UnSubscribeGameEvent(GameEvent e, Action<Dictionary<string, object>> a)
		{
			if (gameEvents.ContainsKey(e))
			{
				gameEvents[e].Remove(a);
			}
		}
	}
}