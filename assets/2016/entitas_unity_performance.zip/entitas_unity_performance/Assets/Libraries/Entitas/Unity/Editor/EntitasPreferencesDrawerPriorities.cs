﻿namespace Entitas.Unity {
    
    public static class EntitasPreferencesDrawerPriorities {

        public const int preferences = 0;
        public const int codeGenerator = 10;
        public const int visualDebugging = 20;
    }
}
