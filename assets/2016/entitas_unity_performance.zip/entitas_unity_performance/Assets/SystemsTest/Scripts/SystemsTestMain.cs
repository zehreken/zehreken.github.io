﻿using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

namespace Performance.Entitas
{
	public class SystemsTestMain : MonoBehaviour
	{
		private ITest _test;
		private float _deltatime = 0f;
		private List<float> _lastHundredFps = new List<float>();
		private string _fpsText = "";
		private Stopwatch _sw = new Stopwatch();

		void Start()
		{
		}

		void Update()
		{
			if (_test != null)
			{
				_test.Update();
				_deltatime += (Time.deltaTime - _deltatime) * 0.1f;

				float miliseconds = _deltatime * 1000f;
				float fps = 1f / _deltatime;

				_lastHundredFps.Add(fps);
				if (_lastHundredFps.Count > 500)
					_lastHundredFps.RemoveAt(0);

				float fpsSum = 0f;
				for (int i = 0; i < _lastHundredFps.Count; i++)
				{
					fpsSum += _lastHundredFps[i];
				}
				float averageFps = fpsSum / _lastHundredFps.Count;

				_fpsText = string.Format("{0:0.0} ms ({1:0.} fps) ({2:0.0} average fps)", miliseconds, fps, averageFps);
			}
		}

		void OnGUI()
		{
			GUI.color = Color.black;
			DrawFPSDisplay();
		}

		private void DrawFPSDisplay()
		{
			GUILayout.Label(_fpsText);
		}

		private void DrawButtons()
		{
			if (_test == null)
			{
				if (GUILayout.Button("Start Test"))
				{
					_sw.Start();
					_test = new SystemsTest();
					_test.Initialize();
					_sw.Reset();
				}
			}
			else
			{
				if (GUILayout.Button("Stop Test"))
				{
					_test.Destroy();
					_test = null;
					_lastHundredFps = new List<float>();
				}
			}
		}
	}
}