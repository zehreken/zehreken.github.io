﻿using Entitas;
using Performance.Entitas;
using UnityEngine;

public class SystemsTest : ITest
{
	private Systems _systems;
	private GameObject _cubeContainer;
	private Pools _pools;

	public void Initialize()
	{
		Pools.sharedInstance.SetAllPools();
		_pools = Pools.sharedInstance;

		_systems = new Systems();

//		_systems.Add()
	}

	public void Update()
	{
		_systems.Execute();
	}

	public string GetName()
	{
		return "SystemsTest";
	}

	public void Destroy()
	{
		_systems.DeactivateReactiveSystems();
		Object.Destroy(_cubeContainer);
		_pools.pool.DestroyAllEntities();
		_pools.pool.Reset();
	}
}
