﻿using System;
using System.Collections.Generic;
using System.Text;

namespace wildcard_test
{
	public static class HashSetSearch
	{
		private static HashSet<string> wordSet = new HashSet<string>();
		private static StringBuilder sb = new StringBuilder();

		static HashSetSearch()
		{
			wordSet = ParseDictionaryFile("English.txt");
		}

		private static HashSet<string> ParseDictionaryFile(string path)
		{
			string text = System.IO.File.ReadAllText(path);
			string[] words = text.Split('\n');

			return new HashSet<string>(words);
		}

		public static void SearchWord(string word)
		{
			char[] chars = word.ToCharArray();
			List<int> wildcardIndices = new List<int>();
			for (int i = 0; i < chars.Length; i++)
			{
				if (chars[i] == '*')
				{
					wildcardIndices.Add(i);
				}
			}

			if (wildcardIndices.Count > 5)
			{
				Console.WriteLine("Too many wildcards in the word, {0}", wildcardIndices.Count);
				return;
			}

			List<string> source = LetterDictionary.all;
			List<string> results = LetterDictionary.all;

			int k = wildcardIndices.Count;
			while (k > 1)
			{
				results = CartesianProduct(results, source);
				k--;
			}

			List<string> validWords = new List<string>();
			foreach (string s in results)
			{
				for (int i = 0; i < chars.Length; i++)
				{
					for (int j = 0; j < wildcardIndices.Count; j++)
					{
						if (i == wildcardIndices[j])
						{
							chars[i] = s[j];
						}
					}
				}

				string newWord = sb.Append(chars).ToString().ToLower();
				if (wordSet.Contains(newWord))
				{
					validWords.Add(newWord);
				}
				sb.Clear();
			}

			Console.WriteLine(validWords.Count);

			int score = 0;
			string cached = "";
			foreach (string w in validWords)
			{
				int wordScore = Utils.GetWordScore(w);
				if (wordScore > score)
				{
					score = wordScore;
					cached = w;
				}
			}

			Console.WriteLine("{0} is the word with highest score, {1}", cached, score);
		}

		private static List<string> CartesianProduct(List<string> sourceOne, List<string> sourceTwo)
		{
			List<string> pairs = new List<string>();
			foreach (string a in sourceOne)
			{
				foreach (string b in sourceTwo)
				{
					pairs.Add(a + b);
				}
			}

			return pairs;
		}
	}
}

