﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace wildcard_test
{
	public static class Utils
	{
		public static void OrderDictionaryByScore(string path)
		{
			Stopwatch sw = new Stopwatch();
			sw.Start();
			Console.WriteLine("Loading text asset to order... : {0}", sw.ElapsedTicks);
			string text = System.IO.File.ReadAllText(path);
			string[] words = text.Split('\n');

			Console.WriteLine("Loaded text asset...");
			Console.WriteLine("Initializing string list...");
			List<string> wordList = new List<string>(words);
			Console.WriteLine("Starting to order string list with {0} strings", wordList.Count);
			sw.Restart();
			wordList.Sort(new ScoreComparer());

			Console.WriteLine("Finished ordering... : {0}", sw.ElapsedTicks);
			sw.Restart();
			Console.WriteLine("Concateneting strings...");
			StringBuilder sb = new StringBuilder();
			string newText = "";
			foreach (string s in wordList)
			{
				sb.Append(s);
				sb.Append("\n");
			}
			newText = sb.ToString();

			Console.WriteLine("Saving ordered file... : {0}", sw.ElapsedTicks);
			sw.Stop();
			System.IO.File.WriteAllText("EnglishOrdered.txt", newText);
			Console.WriteLine("Finished");
		}

		public static string CharArrayToString(char[] chars)
		{
			StringBuilder sb = new StringBuilder();
			sb.Append(chars);

			return sb.ToString();
		}

		public static int GetWordScore(string word)
		{
			word = word.ToUpper();
			int wordScore = 0;
			foreach (char c in word)
			{
				if (LetterDictionary.letters.ContainsKey(c))
					wordScore += LetterDictionary.letters[c].score;
			}

			int bonusScore = GetBonusScore(word.Length);
			wordScore += bonusScore;

			return wordScore;
		}

		private static int GetBonusScore(int wordLength)
		{
			int[] bonusPoints = { 0, 1, 3, 6, 10, 15, 21, 28 };
			wordLength -= 3;

			if (wordLength < 0)
				wordLength = 0;
			else if (wordLength >= bonusPoints.Length)
				wordLength = bonusPoints.Length - 1;

			return bonusPoints[wordLength];
		}
	}

	public class ScoreComparer : IComparer<string>
	{
		public int Compare(string x, string y)
		{
			return Utils.GetWordScore(y).CompareTo(Utils.GetWordScore(x));
		}
	}
}

