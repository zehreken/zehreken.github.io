﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace wildcard_test
{
	public static class RegExSearch
	{
		private static readonly Dictionary<int, List<string>> letterCountToWordMap = new Dictionary<int, List<string>>();

		static RegExSearch()
		{
			letterCountToWordMap = ParseDictionaryFile("EnglishOrdered.txt");
		}

		private static Dictionary<int, List<string>> ParseDictionaryFile(string path)
		{
			string text = System.IO.File.ReadAllText(path);
			string[] words = text.Split('\n');

			var temp = new Dictionary<int, List<string>>();
			for (int i = 0; i < words.Length; i++)
			{
				int letterCount = words[i].Length;
				if (temp.ContainsKey(letterCount))
				{
					temp[letterCount].Add(words[i]);
				}
				else
				{
					temp.Add(letterCount, new List<string> { words[i] });
				}
			}

			return temp;
		}

		public static void SearchWord(string word)
		{
			if (!letterCountToWordMap.ContainsKey(word.Length))
				return;
			
			word = word.Replace('*', '.');
			Console.WriteLine(word);
			Regex regex = new Regex(word);
			List<string> listToSearch = letterCountToWordMap[word.Length];
			foreach (string s in listToSearch)
			{
				Match match = regex.Match(s);
				if (match.Success)
				{
					Console.WriteLine("{0} is the word with highest score, {1} and has {2} letters", match.Value, Utils.GetWordScore(match.Value), match.Value.Length);
					break;
				}
			}
		}

		
	}
}

