﻿//#define REGEX
using System;
using System.Diagnostics;

namespace wildcard_test
{
	class MainClass
	{
		private static Mode mode = Mode.SEARCH;

		public static void Main(string[] args)
		{
			Console.ForegroundColor = ConsoleColor.White;
			Console.BackgroundColor = ConsoleColor.Yellow;

			switch (mode)
			{
				case Mode.ORDER:
					OrderMode();
					break;
				case Mode.SEARCH:
					SearchMode();
					break;
			}
		}

		public static void OrderMode()
		{
			Utils.OrderDictionaryByScore("English.txt");
		}

		public static void SearchMode()
		{
			Stopwatch sw = new Stopwatch();
			Console.WriteLine("Type a word and press Enter to search");
			int keyCode;
			string word = "";
			do
			{
				keyCode = Console.Read();
				if (keyCode == Convert.ToInt32(ConsoleKey.Spacebar))
				{
					Console.WriteLine("\nLooking for {0}", word);
					sw.Start();

					#if REGEX
					RegExSearch.SearchWord(word);
					#else
					HashSetSearch.SearchWord(word);
					#endif

					Console.WriteLine("Time passed: {0} {1}", sw.ElapsedMilliseconds, sw.ElapsedTicks);
					sw.Reset();
					word = "";
				}
				else
				{
					word += Convert.ToChar(keyCode).ToString();
				}
			}
			while (keyCode != Convert.ToInt32(ConsoleKey.Escape));
		}
	}

	public enum Mode
	{
		ORDER,
		SEARCH
	}
}
