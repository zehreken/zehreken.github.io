﻿using System;
using System.Collections.Generic;

namespace wildcard_test
{
	public struct LetterData
	{
		public readonly bool isVowel;
		public readonly int score;
		public readonly int weight;

		public LetterData(bool isVowel, int score, int weight)
		{
			this.isVowel = isVowel;
			this.score = score;
			this.weight = weight;
		}
	}

	public static class LetterDictionary
	{
		public static List<string> all = new List<string> { "A", "E", "I", "O", "U", "B", "C", "D", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "X", "Y", "Z" };

		public static Dictionary<char, LetterData> letters = new Dictionary<char, LetterData>
		{
			{ 'A', new LetterData(true, 1, 16) },
			{ 'E', new LetterData(true, 1, 24) },
			{ 'I', new LetterData(true, 1, 13) },
			{ 'O', new LetterData(true, 1, 15) },
			{ 'U', new LetterData(true, 1, 7) },
			{ 'B', new LetterData(false, 3, 4) },
			{ 'C', new LetterData(false, 3, 6) },
			{ 'D', new LetterData(false, 2, 8) },
			{ 'F', new LetterData(false, 4, 4) },
			{ 'G', new LetterData(false, 2, 5) },
			{ 'H', new LetterData(false, 4, 5) },
			{ 'J', new LetterData(false, 8, 2) },
			{ 'K', new LetterData(false, 5, 2) },
			{ 'L', new LetterData(false, 1, 7) },
			{ 'M', new LetterData(false, 3, 6) },
			{ 'N', new LetterData(false, 1, 13) },
			{ 'P', new LetterData(false, 3, 4) },
			{ 'Q', new LetterData(false, 10, 2) },
			{ 'R', new LetterData(false, 1, 13) },
			{ 'S', new LetterData(false, 1, 10) },
			{ 'T', new LetterData(false, 1, 15) },
			{ 'V', new LetterData(false, 4, 3) },
			{ 'W', new LetterData(false, 4, 4) },
			{ 'X', new LetterData(false, 8, 2) },
			{ 'Y', new LetterData(false, 4, 4) },
			{ 'Z', new LetterData(false, 10, 2) },
			{ '*', new LetterData(false, 10, 0) }
		};
	}
}
